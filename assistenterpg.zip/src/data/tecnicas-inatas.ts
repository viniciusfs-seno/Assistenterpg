// src/data/tecnicas-inatas.ts - TÉCNICAS COM ARRAY DE CLÃS

import { TecnicaInataData, ClaType } from '../types/character';

export const TECNICAS_INATAS: TecnicaInataData[] = [

  // ========== TÉCNICAS HEREDITÁRIAS COM MÚLTIPLOS CLÃS ==========

  {
    id: 'infinito',
    nome: 'Infinito',
    tipo: 'hereditaria',
    cla: ['gojo', 'okkotsu'] as ClaType[], // ✅ AMBOS OS CLÃS
    descricao: 'Técnica que permite controlar o espaço em nível atômico, criando uma barreira infinita.',
  },
  {
    id: 'copiar',
    nome: 'Copiar',
    tipo: 'hereditaria',
    cla: ['gojo', 'okkotsu'] as ClaType[], // ✅ AMBOS OS CLÃS
    descricao: 'Capacidade de copiar técnicas de outros feiticeiros após observação.',
  },

  // ========== TÉCNICAS HEREDITÁRIAS - CLÃ ZENIN ==========

  {
    id: 'dez_sombras',
    nome: 'Técnica das 10 Sombras',
    tipo: 'hereditaria',
    cla: 'zenin' as ClaType,
    descricao: 'Permite invocar 10 shikigamis diferentes usando sombras como intermediárias.',
  },
  {
    id: 'tecnica_projecao',
    nome: 'Técnica de Projeção',
    tipo: 'hereditaria',
    cla: 'zenin' as ClaType,
    descricao: 'Divide o movimento em 24 frames por segundo, permitindo prever e contra-atacar.',
  },
  {
    id: 'plantas_desastre',
    nome: 'Plantas do Desastre',
    tipo: 'hereditaria',
    cla: 'zenin' as ClaType,
    descricao: 'Cria e controla plantas amaldiçoadas com propriedades letais.',
  },

  // ========== TÉCNICAS HEREDITÁRIAS - CLÃ KAMO ==========

  {
    id: 'manipulacao_sangue',
    nome: 'Manipulação de Sangue',
    tipo: 'hereditaria',
    cla: 'kamo' as ClaType,
    descricao: 'Controle total sobre o próprio sangue e de outros seres, permitindo ataques e defesas.',
  },
  {
    id: 'oceano_desastroso',
    nome: 'Oceano Desastroso',
    tipo: 'hereditaria',
    cla: 'kamo' as ClaType,
    descricao: 'Invoca uma onda massiva de energia amaldiçoada que inunda o campo de batalha.',
  },
  {
    id: 'transfiguracao_ociosa',
    nome: 'Transfiguração Ociosa',
    tipo: 'hereditaria',
    cla: 'kamo' as ClaType,
    descricao: 'Permite remodelar a alma e corpo de alvos tocados.',
  },

  // ========== OUTRAS TÉCNICAS HEREDITÁRIAS ==========

  {
    id: 'fala_amaldicoada',
    nome: 'Fala Amaldiçoada',
    tipo: 'hereditaria',
    cla: 'inumaki' as ClaType,
    descricao: 'Palavras se tornam comandos absolutos que obrigam o alvo a obedecer.',
  },
  {
    id: 'santuario',
    nome: 'Santuário',
    tipo: 'hereditaria',
    cla: 'ryomen' as ClaType,
    descricao: 'Domínio de cortes invisíveis que dilaceram tudo dentro de seu alcance.',
  },
  {
    id: 'gravidade_zero',
    nome: 'Gravidade Zero',
    tipo: 'hereditaria',
    cla: 'itadori' as ClaType,
    descricao: 'Manipula a gravidade em uma área, anulando ou intensificando seus efeitos.',
  },
  {
    id: 'chamas_desastre',
    nome: 'Chamas do Desastre',
    tipo: 'hereditaria',
    cla: 'ryomen' as ClaType,
    descricao: 'Invoca chamas negras devastadoras que consomem energia amaldiçoada.',
  },
  {
    id: 'furia_agni',
    nome: 'Fúria de Agni',
    tipo: 'hereditaria',
    cla: 'ram' as ClaType,
    descricao: 'Invoca chamas divinas capazes de purificar e destruir maldições.',
  },
  {
    id: 'tecnica_boneca_palha',
    nome: 'Técnica da Boneca de Palha',
    tipo: 'hereditaria',
    cla: 'kugisaki' as ClaType,
    descricao: 'Usa pregos e bonecas para infligir dano à distância através de conexões.',
  },
  {
    id: 'manipulacao_ceu',
    nome: 'Manipulação do Céu',
    tipo: 'hereditaria',
    cla: 'fujiwara' as ClaType,
    descricao: 'Controla fenômenos atmosféricos como raios, ventos e tempestades.',
  },
  {
    id: 'fabricacao_amaldicoada',
    nome: 'Fabricação Amaldiçoada',
    tipo: 'hereditaria',
    cla: 'haganezuka' as ClaType,
    descricao: 'Cria armas e objetos imbuídos com energia amaldiçoada permanentemente.',
  },

  // ========== TÉCNICAS NÃO-HEREDITÁRIAS ==========

  {
    id: 'restricao_celestial',
    nome: 'Restrição Celestial',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Troca energia amaldiçoada por capacidades físicas sobre-humanas.',
  },
  {
    id: 'restricao_congenita',
    nome: 'Restrição Congênita',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Limitação inata que concede poder em troca de restrições severas.',
  },
  {
    id: 'manipulacao_maldicao',
    nome: 'Manipulação de Maldição',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Controla e absorve espíritos amaldiçoados.',
  },
  {
    id: 'tribunal_julgamento',
    nome: 'Tribunal de Julgamento',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Cria regras vinculativas que afetam todos dentro do domínio.',
  },
  {
    id: 'furia_estelar',
    nome: 'Fúria Estelar',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Dispara rajadas concentradas de energia amaldiçoada.',
  },
  {
    id: 'tecnica_razao',
    nome: 'Técnica de Razão (7/3)',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Cria pontos fracos no alvo através de cálculos matemáticos precisos.',
  },
  {
    id: 'formacao_gelo',
    nome: 'Formação de Gelo',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Gera e manipula gelo amaldiçoado.',
  },
  {
    id: 'energia_eletrificada',
    nome: 'Energia Amaldiçoada Eletrificada',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Imbui energia amaldiçoada com propriedades elétricas.',
  },
  {
    id: 'nulificacao',
    nome: 'Nulificação',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Anula técnicas amaldiçoadas em uma área.',
  },
  {
    id: 'manipulacao_fantoches',
    nome: 'Manipulação de Fantoches',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Controla corpos como marionetes.',
  },
  {
    id: 'troca_boogie_woogie',
    nome: 'Troca (Boogie Woogie)',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Troca posições entre dois alvos instantaneamente.',
  },
  {
    id: 'teletransporte',
    nome: 'Teletransporte',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Move-se instantaneamente entre locais.',
  },
  {
    id: 'milagres',
    nome: 'Milagres',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Altera probabilidades e cria eventos improváveis.',
  },
  {
    id: 'trem_amor_puro',
    nome: 'Trem do Amor Puro Privado',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Invoca um trem amaldiçoado que persegue alvos.',
  },
  {
    id: 'tecnica_clonagem',
    nome: 'Técnica de Clonagem',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Cria cópias temporárias de si mesmo.',
  },
  {
    id: 'encantamento_inverso',
    nome: 'Encantamento do Inverso',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Inverte os efeitos de técnicas amaldiçoadas.',
  },
  {
    id: 'envenenamento',
    nome: 'Envenenamento',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Inflige venenos amaldiçoados que corroem energia vital.',
  },
  {
    id: 'carne_explosiva',
    nome: 'Carne Explosiva',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Transforma partes do corpo em explosivos amaldiçoados.',
  },
  {
    id: 'armamento_divino',
    nome: 'Armamento Divino',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Manifesta armas lendárias imbuídas com poder divino.',
  },
  {
    id: 'sete_caminhos',
    nome: 'Sete Caminhos Mundanos',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Domina sete técnicas elementais diferentes.',
  },
  {
    id: 'surto_temporal',
    nome: 'Surto Temporal',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Manipula o fluxo do tempo em pequena escala.',
  },
  {
    id: 'orquidea_sarkica',
    nome: 'Orquídea Sárkica',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Invoca flores carnívoras amaldiçoadas.',
  },
  {
    id: 'dadiva_lavoisier',
    nome: 'Dádiva de Lavoisier',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Transmuta matéria através de reações alquímicas.',
  },
  {
    id: 'descarga_energia',
    nome: 'Descarga de Energia Amaldiçoada',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Libera toda energia acumulada em uma explosão devastadora.',
  },
  {
    id: 'manipulacao_fotografias',
    nome: 'Manipulação de Fotografias',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Altera a realidade através de fotos modificadas.',
  },
  {
    id: 'bloqueio_tecnica',
    nome: 'Bloqueio de Técnica',
    tipo: 'nao_hereditaria',
    cla: null,
    descricao: 'Impede alvos de usar suas técnicas inatas temporariamente.',
  },
];
